from django.apps import AppConfig


class DonatePostConfig(AppConfig):
    name = 'donate_post'
