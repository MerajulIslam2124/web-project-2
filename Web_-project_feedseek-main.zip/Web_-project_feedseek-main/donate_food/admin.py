from django.contrib import admin
from .models import DonatePost
# Register your models here.


admin.site.register(DonatePost)