from django.apps import AppConfig


class DonateFoodConfig(AppConfig):
    name = 'donate_food'
